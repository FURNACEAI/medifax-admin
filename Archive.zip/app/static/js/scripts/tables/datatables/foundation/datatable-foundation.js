/*=========================================================================================
    File Name: datatable-foundation.js
    Description: Foundation Datatable
    ----------------------------------------------------------------------------------------
    Item Name: Stack - Responsive Admin Theme
    Version: 2.1
    Author: Pixinvent
    Author URL: hhttp://www.themeforest.net/user/pixinvent
==========================================================================================*/

//--- Styling Datatable ---


$(document).ready(function() {

//js of Foundation
    $('.foundation').DataTable();

} );
